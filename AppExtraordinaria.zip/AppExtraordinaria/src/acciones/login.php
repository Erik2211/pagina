<?php
	if (!isset($_SESSION)){
	    session_start();
	}    
	require_once("../funciones.php"); 

	/*
		Actualmente el login está desactivado
	}*/
?>